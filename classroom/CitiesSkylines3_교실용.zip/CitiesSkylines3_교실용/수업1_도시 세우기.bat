@echo off
set "P=%~dp0cities-skylines-3.html"
set "P=%P:\=/%"
start "" "file:///%P%?seed=2026&nohelp=0"
