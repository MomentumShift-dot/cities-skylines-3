@echo off
set "P=%~dp0cities-skylines-3.html"
start "" "%P%"
