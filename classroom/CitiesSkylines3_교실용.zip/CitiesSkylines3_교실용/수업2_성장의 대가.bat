@echo off
set "P=%~dp0cities-skylines-3.html"
set "P=%P:\=/%"
start "" "file:///%P%?demo=12&seed=2026&overlay=air"
