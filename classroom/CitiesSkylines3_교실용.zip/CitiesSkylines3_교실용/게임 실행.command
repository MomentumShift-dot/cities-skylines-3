#!/bin/sh
D=$(cd "$(dirname "$0")" && pwd)
if command -v open >/dev/null 2>&1; then open "$D/cities-skylines-3.html"
else xdg-open "$D/cities-skylines-3.html"; fi
